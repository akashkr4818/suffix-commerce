require("dotenv").config();
const express = require("express");
const session = require("express-session");
const PgSession = require("connect-pg-simple")(session);
const { Pool } = require("pg");
const bcrypt = require("bcryptjs");
const helmet = require("helmet");
const path = require("path");

const app = express();
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: process.env.NODE_ENV === "production" ? { rejectUnauthorized: false } : false
});

app.set("trust proxy", 1);
app.use(helmet({ contentSecurityPolicy: false }));
app.use(express.json({ limit: "1mb" }));
app.use(express.urlencoded({ extended: false }));
app.use(session({
  store: new PgSession({ pool, tableName: "user_sessions", createTableIfMissing: true }),
  secret: process.env.SESSION_SECRET || "development-only-change-this-secret",
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 7 * 24 * 60 * 60 * 1000
  }
}));
app.use(express.static(path.join(__dirname, "public")));

async function initDb() {
  await pool.query(`
    CREATE TABLE IF NOT EXISTS users (
      id BIGSERIAL PRIMARY KEY,
      name TEXT NOT NULL,
      email TEXT UNIQUE NOT NULL,
      password_hash TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS products (
      id BIGSERIAL PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL DEFAULT '',
      price_paise INTEGER NOT NULL CHECK (price_paise >= 0),
      image_url TEXT NOT NULL DEFAULT '',
      category TEXT NOT NULL DEFAULT 'General',
      inventory INTEGER NOT NULL DEFAULT 0 CHECK (inventory >= 0),
      active BOOLEAN NOT NULL DEFAULT TRUE,
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
    CREATE TABLE IF NOT EXISTS orders (
      id BIGSERIAL PRIMARY KEY,
      user_id BIGINT REFERENCES users(id) ON DELETE SET NULL,
      customer_name TEXT NOT NULL,
      email TEXT NOT NULL,
      address TEXT NOT NULL,
      items JSONB NOT NULL,
      total_paise INTEGER NOT NULL,
      status TEXT NOT NULL DEFAULT 'pending',
      created_at TIMESTAMPTZ NOT NULL DEFAULT NOW()
    );
  `);
  const count = await pool.query("SELECT COUNT(*)::int AS n FROM products");
  if (count.rows[0].n === 0) {
    await pool.query(
      `INSERT INTO products (title, description, price_paise, image_url, category, inventory) VALUES
      ('Everyday Backpack', 'A clean, durable backpack for daily essentials.', 249900, 'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=900&q=85', 'Accessories', 18),
      ('Minimal Sneakers', 'Comfort-first sneakers with a timeless profile.', 329900, 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=900&q=85', 'Footwear', 12),
      ('Studio Headphones', 'Immersive sound and a lightweight fit.', 499900, 'https://images.unsplash.com/photo-150左右?auto=format&fit=crop&w=900&q=85', 'Electronics', 9),
      ('Daily Bottle', 'Reusable stainless steel bottle for your everyday carry.', 89900, 'https://images.unsplash.com/photo-1602143407151-7111542de6e8?auto=format&fit=crop&w=900&q=85', 'Lifestyle', 30)`
    );
    // Correct the intentionally neutral demo image URL with a valid Unsplash image.
    await pool.query("UPDATE products SET image_url = $1 WHERE title = $2", [
      "https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=900&q=85",
      "Studio Headphones"
    ]);
  }
}

function requireAuth(req, res, next) {
  if (!req.session.user) return res.status(401).json({ error: "Please sign in first." });
  next();
}
function requireAdmin(req, res, next) {
  if (!req.session.user || req.session.user.role !== "admin") {
    return res.status(403).json({ error: "Admin access required." });
  }
  next();
}
function validEmail(email) {
  return typeof email === "string" && /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(email);
}

app.get("/api/health", (_req, res) => res.json({ ok: true, app: "Suffix" }));
app.get("/api/me", (req, res) => res.json({ user: req.session.user || null }));

app.get("/api/products", async (req, res, next) => {
  try {
    const q = String(req.query.q || "").trim().slice(0, 80);
    const result = q
      ? await pool.query("SELECT id,title,description,price_paise,image_url,category,inventory FROM products WHERE active=TRUE AND (title ILIKE $1 OR category ILIKE $1) ORDER BY created_at DESC", [`%${q}%`])
      : await pool.query("SELECT id,title,description,price_paise,image_url,category,inventory FROM products WHERE active=TRUE ORDER BY created_at DESC");
    res.json({ products: result.rows });
  } catch (e) { next(e); }
});

app.post("/api/register", async (req, res, next) => {
  try {
    const name = String(req.body.name || "").trim().slice(0, 80);
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    if (name.length < 2 || !validEmail(email) || password.length < 8) {
      return res.status(400).json({ error: "Enter your name, a valid email, and a password with at least 8 characters." });
    }
    const hash = await bcrypt.hash(password, 12);
    const result = await pool.query(
      "INSERT INTO users(name,email,password_hash) VALUES($1,$2,$3) RETURNING id,name,email,role",
      [name, email, hash]
    );
    req.session.user = result.rows[0];
    res.status(201).json({ user: req.session.user });
  } catch (e) {
    if (e.code === "23505") return res.status(409).json({ error: "That email is already registered." });
    next(e);
  }
});

app.post("/api/login", async (req, res, next) => {
  try {
    const email = String(req.body.email || "").trim().toLowerCase();
    const password = String(req.body.password || "");
    const result = await pool.query("SELECT id,name,email,password_hash,role FROM users WHERE email=$1", [email]);
    const user = result.rows[0];
    if (!user || !(await bcrypt.compare(password, user.password_hash))) {
      return res.status(401).json({ error: "Email or password is incorrect." });
    }
    delete user.password_hash;
    req.session.regenerate(err => {
      if (err) return next(err);
      req.session.user = user;
      res.json({ user });
    });
  } catch (e) { next(e); }
});

app.post("/api/logout", (req, res, next) => {
  req.session.destroy(err => {
    if (err) return next(err);
    res.clearCookie("connect.sid");
    res.json({ ok: true });
  });
});

app.post("/api/orders", async (req, res, next) => {
  const client = await pool.connect();
  try {
    const { name, email, address, items } = req.body || {};
    if (String(name || "").trim().length < 2 || !validEmail(email) ||
        String(address || "").trim().length < 8 || !Array.isArray(items) ||
        items.length < 1 || items.length > 30) {
      return res.status(400).json({ error: "Please enter valid contact, address, and cart details." });
    }
    await client.query("BEGIN");
    let total = 0;
    const finalItems = [];
    for (const item of items) {
      const id = Number(item.id), qty = Number(item.quantity);
      if (!Number.isSafeInteger(id) || !Number.isSafeInteger(qty) || qty < 1 || qty > 20) {
        throw Object.assign(new Error("Invalid cart item."), { status: 400 });
      }
      const p = await client.query("SELECT id,title,price_paise,inventory,image_url FROM products WHERE id=$1 AND active=TRUE FOR UPDATE", [id]);
      if (!p.rowCount) throw Object.assign(new Error("A product is no longer available."), { status: 400 });
      if (p.rows[0].inventory < qty) throw Object.assign(new Error(`${p.rows[0].title} has insufficient stock.`), { status: 409 });
      await client.query("UPDATE products SET inventory=inventory-$1 WHERE id=$2", [qty, id]);
      total += p.rows[0].price_paise * qty;
      finalItems.push({ id, title: p.rows[0].title, price_paise: p.rows[0].price_paise, quantity: qty, image_url: p.rows[0].image_url });
    }
    const order = await client.query(
      "INSERT INTO orders(user_id,customer_name,email,address,items,total_paise) VALUES($1,$2,$3,$4,$5,$6) RETURNING id,total_paise,status,created_at",
      [req.session.user?.id || null, String(name).trim(), String(email).trim().toLowerCase(), String(address).trim(), JSON.stringify(finalItems), total]
    );
    await client.query("COMMIT");
    res.status(201).json({ order: order.rows[0], message: "Order placed. Payment is not yet collected online." });
  } catch (e) {
    await client.query("ROLLBACK");
    next(e);
  } finally { client.release(); }
});

app.get("/api/admin/summary", requireAdmin, async (_req, res, next) => {
  try {
    const [products, orders, revenue, recent] = await Promise.all([
      pool.query("SELECT COUNT(*)::int AS count FROM products WHERE active=TRUE"),
      pool.query("SELECT COUNT(*)::int AS count FROM orders"),
      pool.query("SELECT COALESCE(SUM(total_paise),0)::bigint AS total FROM orders WHERE status <> 'cancelled'"),
      pool.query("SELECT id,customer_name,email,total_paise,status,created_at FROM orders ORDER BY created_at DESC LIMIT 8")
    ]);
    res.json({ products: products.rows[0].count, orders: orders.rows[0].count, revenue_paise: revenue.rows[0].total, recent_orders: recent.rows });
  } catch (e) { next(e); }
});

app.get("/api/admin/products", requireAdmin, async (_req, res, next) => {
  try {
    const r = await pool.query("SELECT * FROM products ORDER BY created_at DESC");
    res.json({ products: r.rows });
  } catch (e) { next(e); }
});
app.post("/api/admin/products", requireAdmin, async (req, res, next) => {
  try {
    const { title, description = "", image_url = "", category = "General" } = req.body || {};
    const price = Number(req.body.price_rupees), inventory = Number(req.body.inventory);
    if (!String(title || "").trim() || !Number.isFinite(price) || price < 0 || !Number.isSafeInteger(inventory) || inventory < 0) {
      return res.status(400).json({ error: "Product name, valid price, and stock are required." });
    }
    const r = await pool.query(
      "INSERT INTO products(title,description,price_paise,image_url,category,inventory) VALUES($1,$2,$3,$4,$5,$6) RETURNING *",
      [String(title).trim().slice(0,120), String(description).slice(0,1000), Math.round(price*100), String(image_url).slice(0,1000), String(category).slice(0,80), inventory]
    );
    res.status(201).json({ product: r.rows[0] });
  } catch (e) { next(e); }
});
app.patch("/api/admin/orders/:id", requireAdmin, async (req, res, next) => {
  try {
    const allowed = ["pending", "processing", "shipped", "completed", "cancelled"];
    const status = String(req.body.status || "");
    if (!allowed.includes(status)) return res.status(400).json({ error: "Invalid order status." });
    const r = await pool.query("UPDATE orders SET status=$1 WHERE id=$2 RETURNING id,status", [status, req.params.id]);
    if (!r.rowCount) return res.status(404).json({ error: "Order not found." });
    res.json({ order: r.rows[0] });
  } catch (e) { next(e); }
});

// Create the first admin with ADMIN_EMAIL and ADMIN_PASSWORD environment variables.
async function seedAdmin() {
  const email = String(process.env.ADMIN_EMAIL || "").trim().toLowerCase();
  const password = String(process.env.ADMIN_PASSWORD || "");
  if (!email || password.length < 12) return;
  const found = await pool.query("SELECT id FROM users WHERE email=$1", [email]);
  if (!found.rowCount) {
    const hash = await bcrypt.hash(password, 12);
    await pool.query("INSERT INTO users(name,email,password_hash,role) VALUES($1,$2,$3,'admin')", ["Suffix Admin", email, hash]);
    console.log("Suffix admin account created.");
  }
}

app.use("/api", (err, _req, res, _next) => {
  console.error(err);
  res.status(err.status || 500).json({ error: err.status ? err.message : "Server error. Please try again." });
});
app.get("*", (_req, res) => res.sendFile(path.join(__dirname, "public", "index.html")));

const port = Number(process.env.PORT || 3000);
initDb().then(seedAdmin).then(() => {
  app.listen(port, "0.0.0.0", () => console.log(`Suffix running on port ${port}`));
}).catch(err => {
  console.error("Database startup failed:", err);
  process.exit(1);
});
