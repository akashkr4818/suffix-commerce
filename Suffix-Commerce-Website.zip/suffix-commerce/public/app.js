const $ = (s, root=document) => root.querySelector(s);
const $$ = (s, root=document) => [...root.querySelectorAll(s)];
const money = n => new Intl.NumberFormat("en-IN", {style:"currency",currency:"INR",maximumFractionDigits:0}).format(Number(n||0)/100);
const state = { products: [], cart: JSON.parse(localStorage.getItem("suffix-cart") || "[]"), category:"All", user:null, authMode:"login" };
let toastTimer;
function toast(message){ const el=$("#toast"); el.textContent=message; el.classList.add("show"); clearTimeout(toastTimer); toastTimer=setTimeout(()=>el.classList.remove("show"),2600); }
function openOverlay(id){ $("#"+id).classList.add("open"); document.body.style.overflow="hidden"; }
function closeOverlay(id){ $("#"+id).classList.remove("open"); if(!$$(".overlay.open").length) document.body.style.overflow=""; }
$$("[data-close]").forEach(b=>b.addEventListener("click",()=>closeOverlay(b.dataset.close)));
$$(".overlay").forEach(el=>el.addEventListener("click",e=>{if(e.target===el)closeOverlay(el.id)}));
document.addEventListener("keydown",e=>{if(e.key==="Escape")$$(".overlay.open").forEach(x=>closeOverlay(x.id))});
async function api(url, options={}) {
  const response=await fetch(url,{credentials:"same-origin",headers:{"Content-Type":"application/json",...(options.headers||{})},...options});
  let data={}; try{data=await response.json()}catch{}
  if(!response.ok) throw new Error(data.error||"Something went wrong.");
  return data;
}
async function loadProducts(){
  try{const data=await api("/api/products");state.products=data.products;renderProducts();}
  catch(e){$("#products").innerHTML='<div class="empty-state">Could not load products. Please refresh the page.</div>';toast(e.message);}
}
function filteredProducts(){
  const q=$("#search").value.trim().toLowerCase();
  return state.products.filter(p=>(state.category==="All"||p.category===state.category)&&(!q||p.title.toLowerCase().includes(q)||p.category.toLowerCase().includes(q)));
}
function renderProducts(){
  const list=filteredProducts(); $("#product-count").textContent=`${list.length} ${list.length===1?"product":"products"}`;
  $("#products").innerHTML=list.length?list.map((p,i)=>`<article class="product-card">
    <div class="product-image-wrap"><img class="product-image" src="${escapeAttr(p.image_url||"")}" alt="${escapeAttr(p.title)}" loading="lazy" onerror="this.style.opacity='.2'">
    ${i===0?'<span class="product-tag">THE EVERYDAY EDIT</span>':""}
    <button class="quick-add" data-add="${p.id}" ${p.inventory<1?"disabled":""}>${p.inventory<1?"Sold out":"Quick add  ＋"}</button></div>
    <div class="product-info"><div class="product-meta"><span class="product-name">${escapeHtml(p.title)}</span><span class="product-price">${money(p.price_paise)}</span></div><div class="product-category">${escapeHtml(p.category)}</div></div></article>`).join(""):'<div class="empty-state">No products found. Try another search.</div>';
  $$("[data-add]").forEach(b=>b.addEventListener("click",()=>addToCart(Number(b.dataset.add))));
}
function escapeHtml(s){return String(s??"").replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function escapeAttr(s){return escapeHtml(s);}
$("#search").addEventListener("input",renderProducts);
$$(".category").forEach(b=>b.addEventListener("click",()=>{$$(".category").forEach(x=>x.classList.remove("active"));b.classList.add("active");state.category=b.dataset.category;renderProducts()}));
function persistCart(){localStorage.setItem("suffix-cart",JSON.stringify(state.cart));renderCart();}
function addToCart(id){const p=state.products.find(x=>Number(x.id)===id);if(!p)return;const item=state.cart.find(x=>x.id===id);if(item){if(item.quantity>=Math.min(20,p.inventory)){toast("Maximum available stock reached.");return;}item.quantity++;}else{if(p.inventory<1){toast("This item is out of stock.");return;}state.cart.push({id,quantity:1});}persistCart();toast("Added to your bag.");}
function cartProducts(){return state.cart.map(item=>{const p=state.products.find(x=>Number(x.id)===item.id);return p?{...p,quantity:item.quantity}:null}).filter(Boolean);}
function renderCart(){
  const items=cartProducts(),count=items.reduce((n,p)=>n+p.quantity,0),total=items.reduce((n,p)=>n+Number(p.price_paise)*p.quantity,0);
  $("#cart-count").textContent=count;$("#drawer-count").textContent=`(${count})`;$("#subtotal").textContent=money(total);$("#checkout-total").textContent=money(total);
  $("#cart-items").innerHTML=items.length?items.map(p=>`<div class="cart-row"><img src="${escapeAttr(p.image_url)}" alt=""><div><h4>${escapeHtml(p.title)}</h4><p>${money(p.price_paise)}</p><div class="qty-control"><button data-qty="${p.id}" data-delta="-1" aria-label="Decrease quantity">−</button><span>${p.quantity}</span><button data-qty="${p.id}" data-delta="1" aria-label="Increase quantity">＋</button></div></div><button class="remove-item" data-remove="${p.id}">Remove</button></div>`).join(""):'<div class="cart-empty">Your bag is waiting for something good.<br><br><a href="#shop" id="shop-from-cart">Explore the collection ↗</a></div>';
  $$("[data-qty]").forEach(b=>b.addEventListener("click",()=>{const item=state.cart.find(x=>x.id===Number(b.dataset.qty));if(!item)return;item.quantity+=Number(b.dataset.delta);if(item.quantity<1)state.cart=state.cart.filter(x=>x.id!==item.id);else{const p=state.products.find(x=>Number(x.id)===item.id);if(item.quantity>Math.min(20,p?.inventory||20)){item.quantity=Math.min(20,p?.inventory||20);toast("Maximum stock reached.");}}persistCart();}));
  $$("[data-remove]").forEach(b=>b.addEventListener("click",()=>{state.cart=state.cart.filter(x=>x.id!==Number(b.dataset.remove));persistCart()}));
  $("#shop-from-cart")?.addEventListener("click",()=>closeOverlay("cart-overlay"));
}
$("#cart-open").addEventListener("click",()=>{renderCart();openOverlay("cart-overlay")});
$("#checkout-open").addEventListener("click",()=>{if(!state.cart.length){toast("Your bag is empty.");return;}closeOverlay("cart-overlay");$("#checkout-message").textContent="";if(state.user){$("#checkout-form").elements.email.value=state.user.email;$("#checkout-form").elements.name.value=state.user.name;}openOverlay("checkout-overlay")});
$("#checkout-form").addEventListener("submit",async e=>{e.preventDefault();const btn=e.submitter;btn.disabled=true;$("#checkout-message").textContent="Placing your order…";try{const form=new FormData(e.currentTarget);const result=await api("/api/orders",{method:"POST",body:JSON.stringify({name:form.get("name"),email:form.get("email"),address:form.get("address"),items:state.cart})});state.cart=[];persistCart();e.currentTarget.reset();$("#checkout-message").textContent=`Order #${result.order.id} created. ${result.message}`;toast("Your order has been placed.");await loadProducts();}catch(err){$("#checkout-message").textContent=err.message;}finally{btn.disabled=false;}});
$("#account-open").addEventListener("click",()=>{setAuthMode("login");$("#auth-message").textContent="";openOverlay("account-overlay")});
function setAuthMode(mode){state.authMode=mode;$$(".auth-tab").forEach(b=>b.classList.toggle("active",b.dataset.auth===mode));$("#name-field").classList.toggle("hidden",mode!=="register");$("#name-field input").required=mode==="register";$("#auth-submit").innerHTML=(mode==="login"?"Sign in":"Create account")+' <span>↗</span>';$("#auth-form").elements.password.autocomplete=mode==="login"?"current-password":"new-password";}
$$(".auth-tab").forEach(b=>b.addEventListener("click",()=>setAuthMode(b.dataset.auth)));
$("#auth-form").addEventListener("submit",async e=>{e.preventDefault();const btn=$("#auth-submit");btn.disabled=true;$("#auth-message").textContent="Please wait…";try{const f=new FormData(e.currentTarget);const result=await api("/api/"+(state.authMode==="login"?"login":"register"),{method:"POST",body:JSON.stringify({name:f.get("name"),email:f.get("email"),password:f.get("password")})});state.user=result.user;$("#auth-message").textContent=`Welcome, ${state.user.name}.`;toast("Signed in successfully.");setTimeout(()=>closeOverlay("account-overlay"),700);if(state.user.role==="admin")openAdmin();}catch(err){$("#auth-message").textContent=err.message;}finally{btn.disabled=false;}});
async function checkUser(){try{const r=await api("/api/me");state.user=r.user;}catch{}}
async function openAdmin(){openOverlay("admin-overlay");$("#admin-content").innerHTML="<p>Loading store dashboard…</p>";try{const d=await api("/api/admin/summary");$("#admin-content").innerHTML=`<div class="admin-stats"><div class="admin-stat"><small>Active products</small><b>${d.products}</b></div><div class="admin-stat"><small>Total orders</small><b>${d.orders}</b></div><div class="admin-stat"><small>Order value (not payment received)</small><b>${money(d.revenue_paise)}</b></div></div><h3>Recent orders</h3>${d.recent_orders.length?`<table class="admin-orders"><thead><tr><th>Order</th><th>Customer</th><th>Total</th><th>Status</th></tr></thead><tbody>${d.recent_orders.map(o=>`<tr><td>#${o.id}</td><td>${escapeHtml(o.customer_name)}</td><td>${money(o.total_paise)}</td><td><select data-order="${o.id}">${["pending","processing","shipped","completed","cancelled"].map(s=>`<option ${o.status===s?"selected":""}>${s}</option>`).join("")}</select></td></tr>`).join("")}</tbody></table>`:"<p>No orders yet.</p>"}<form id="new-product-form" class="admin-form"><h3>Add a product</h3><div class="field"><label>Product name</label><input name="title" required></div><div class="field"><label>Description</label><textarea name="description" rows="2"></textarea></div><div class="field"><label>Price in rupees</label><input name="price_rupees" type="number" min="0" step=".01" required></div><div class="field"><label>Image URL</label><input name="image_url" type="url"></div><div class="field"><label>Category</label><input name="category" value="General"></div><div class="field"><label>Stock quantity</label><input name="inventory" type="number" min="0" step="1" value="10" required></div><button class="primary-button wide" type="submit">Add product <span>↗</span></button></form><button class="text-button" id="logout-button">Sign out</button>`;$$("[data-order]").forEach(sel=>sel.addEventListener("change",async()=>{try{await api("/api/admin/orders/"+sel.dataset.order,{method:"PATCH",body:JSON.stringify({status:sel.value})});toast("Order status updated.");}catch(e){toast(e.message)}}));$("#new-product-form").addEventListener("submit",async e=>{e.preventDefault();const f=new FormData(e.currentTarget);const payload=Object.fromEntries(f.entries());payload.inventory=Number(payload.inventory);payload.price_rupees=Number(payload.price_rupees);try{await api("/api/admin/products",{method:"POST",body:JSON.stringify(payload)});toast("Product added.");e.currentTarget.reset();await loadProducts();await openAdmin();}catch(err){toast(err.message)}});$("#logout-button").addEventListener("click",async()=>{await api("/api/logout",{method:"POST"});state.user=null;closeOverlay("admin-overlay");toast("Signed out.");});}catch(e){$("#admin-content").innerHTML=`<p>${escapeHtml(e.message)}</p><p>To create the first admin, configure ADMIN_EMAIL and ADMIN_PASSWORD in your server environment and redeploy. Admin password must be at least 12 characters.</p><button class="text-button" id="admin-signin">Sign in</button>`;$("#admin-signin").addEventListener("click",()=>{closeOverlay("admin-overlay");$("#account-open").click()});}}
$("#newsletter-form").addEventListener("submit",e=>{e.preventDefault();$("#newsletter-message").textContent="Thanks! Newsletter sign-up is a demo and isn't connected to an email service yet.";e.currentTarget.reset();});
$("#menu-open").addEventListener("click",()=>{const nav=$(".nav");const open=nav.style.display==="flex";nav.style.display=open?"none":"flex";if(!open){nav.style.position="absolute";nav.style.top="65px";nav.style.left="0";nav.style.right="0";nav.style.padding="20px 6%";nav.style.background="var(--paper)";nav.style.flexDirection="column";nav.style.borderBottom="1px solid var(--line)";}});
(async()=>{await checkUser();await loadProducts();renderCart();})();
